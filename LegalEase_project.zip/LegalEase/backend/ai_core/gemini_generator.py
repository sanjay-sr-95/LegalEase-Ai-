from google import genai
from google.genai import types
from backend.config import Settings

class GeminiDocumentGenerator:
    def __init__(self, settings: Settings):
        self.settings = settings
        if not settings.gemini_api_key:
            raise RuntimeError("GEMINI_API_KEY is not configured. Add it to .env.")
        self.client = genai.Client(api_key=settings.gemini_api_key)

    def build_prompt(self, document_type, parties, terms, effective_date):
        return f"""You are a careful legal-document drafting assistant.

Create a professional DRAFT of the requested legal document using only the information supplied by the user. Do not invent names, dates, addresses, amounts, jurisdictions, statutes, or obligations that were not supplied.

DOCUMENT TYPE:
{document_type}

PARTIES:
{parties}

EFFECTIVE DATE:
{effective_date}

USER-SUPPLIED TERMS:
{terms}

Requirements:
1. Produce a clear, structured document suitable for human review.
2. Use a title and numbered sections.
3. Convert supplied terms into sensible clauses without adding unsupported facts.
4. If an important detail is missing, use a bracketed placeholder such as [JURISDICTION] rather than inventing it.
5. Include signature blocks appropriate to the parties.
6. Do not claim the document is guaranteed legally valid or legally sound.
7. Start directly with the document title. Do not use Markdown code fences.
8. End with: DRAFT FOR REVIEW — This AI-generated document is not legal advice and should be reviewed for jurisdiction-specific requirements before use.

Return only the document draft."""

    def generate_document(self, document_type, parties, terms, effective_date):
        response = self.client.models.generate_content(
            model=self.settings.gemini_model,
            contents=self.build_prompt(document_type, parties, terms, effective_date),
            config=types.GenerateContentConfig(
                temperature=0.25,
                max_output_tokens=8192,
            ),
        )
        text = getattr(response, "text", None)
        if not text or not text.strip():
            raise RuntimeError("Gemini returned an empty response.")
        return text.strip()
